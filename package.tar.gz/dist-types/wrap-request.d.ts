export declare function wrapRequest(state: any, request: any, options: any): any;
