export declare function routeMatcher(paths: any): RegExp;
