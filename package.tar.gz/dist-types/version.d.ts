export declare const VERSION = "0.0.0-development";
